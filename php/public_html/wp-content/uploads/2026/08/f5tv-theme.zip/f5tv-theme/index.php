<?php
/**
 * Main template file for F5TV Theme
 * Landing page matching React design
 */

get_header();
?>

<?php
// Hero section
$hero_content = get_posts([
    'post_type' => 'f5tv_conteudo',
    'posts_per_page' => 1,
    'meta_key' => 'is_featured',
    'meta_value' => '1',
]);

$hero_bg = '';
$hero_title = 'CONEXÃO <span class="text-f5-red italic">F5</span>';
$hero_desc = 'Mergulhe nos bastidores do poder, do jornalismo investigativo tático, de documentários de alta voltagem e de esportes ao vivo. Sem censura, com qualidade calibrada de cinema.';

if (!empty($hero_content)) {
    $hero = $hero_content[0];
    $hero_title = get_the_title($hero);
    $hero_desc = get_field('short_description', $hero->ID) ?: get_the_excerpt($hero);
    $hero_bg = get_field('banner_url', $hero->ID) ?: get_the_post_thumbnail_url($hero->ID, 'full');
}
?>

<section id="hero" class="relative h-[560px] px-4 sm:px-8 pt-12 flex flex-col justify-end pb-16 overflow-hidden border-b border-white/5">
    <?php if ($hero_bg): ?>
        <div class="absolute inset-0 bg-cover bg-center opacity-65 grayscale-[0.25]" style="background-image: url('<?php echo esc_url($hero_bg); ?>')"></div>
    <?php else: ?>
        <div class="absolute inset-0 bg-gradient-to-b from-f5-blue to-black"></div>
    <?php endif; ?>
    <div class="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/75 to-transparent z-10"></div>
    <div class="absolute inset-0 bg-gradient-to-t from-[#050505] to-transparent z-10"></div>

    <div class="max-w-4xl mx-auto w-full relative z-20 flex flex-col items-start gap-4 px-4">
        <div class="inline-flex items-center gap-2 bg-f5-red px-2.5 py-0.5 text-[10px] font-mono font-bold rounded uppercase tracking-widest">
            <span>SÉRIE ORIGINAL F5</span>
        </div>

        <h1 class="text-4xl sm:text-6xl md:text-7xl font-black tracking-tighter leading-none text-white max-w-3xl">
            <?php echo $hero_title; ?>
        </h1>

        <p class="text-white/70 text-base md:text-lg max-w-2xl leading-relaxed font-normal">
            <?php echo esc_html($hero_desc); ?>
        </p>

        <div class="flex flex-col sm:flex-row gap-4 w-full h-fit max-w-md mt-4">
            <a href="<?php echo esc_url(home_url('/planos/')); ?>" class="px-8 py-3.5 rounded bg-white text-black font-bold flex items-center justify-center gap-2 hover:bg-f5-red hover:text-white transition-colors text-sm uppercase tracking-wider">
                <span>Assinar Agora</span>
            </a>
            <a href="<?php echo esc_url(home_url('/categoria/series/')); ?>" class="bg-white/10 backdrop-blur-md text-white border border-white/20 px-8 py-3.5 rounded font-bold flex items-center justify-center gap-2 hover:bg-white/20 transition text-sm uppercase tracking-wider">
                <span>Explorar Prévia</span>
            </a>
        </div>

        <div class="flex items-center gap-6 text-[10px] text-white/30 uppercase tracking-[0.2em] font-medium font-mono mt-8">
            <span>&#10003; CANCELAMENTO 100% ONLINE</span>
            <span>&#8226;</span>
            <span>&#10003; FILMES FILTRADOS EM 4K</span>
        </div>
    </div>
</section>

<?php
// Content preview section
$contents = get_posts([
    'post_type' => 'f5tv_conteudo',
    'posts_per_page' => 10,
    'post_status' => 'publish',
]);
?>

<section id="conteudo-previa" class="py-20 px-4 sm:px-8 bg-f5-blue border-b border-white/5">
    <div class="max-w-7xl mx-auto">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-12">
            <div>
                <span class="text-[10px] font-mono font-bold tracking-[0.2em] text-f5-red uppercase">NO CATÁLOGO</span>
                <h2 class="text-3xl md:text-5xl font-black tracking-tight text-white mt-2">Nossos Maiores Sucessos Disponíveis</h2>
            </div>
            <a href="<?php echo esc_url(home_url('/categoria/series/')); ?>" class="text-sm font-semibold text-f5-red hover:text-f5-red flex items-center gap-2 transition-colors uppercase tracking-wider font-mono text-xs">
                <span>Ver catálogo completo</span>
            </a>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <?php foreach ($contents as $item): ?>
                <?php
                $cover = get_field('cover_url', $item->ID) ?: get_the_post_thumbnail_url($item->ID, 'medium');
                $genre = get_field('genre', $item->ID) ?: get_the_category_list(', ', '', $item->ID);
                $age_rating = get_field('age_rating', $item->ID) ?: 'Livre';
                $is_exclusive = get_field('is_exclusive', $item->ID);
                ?>
                <div class="group relative bg-f5-blue-950 border border-white/5 hover:border-f5-red rounded-lg overflow-hidden cursor-pointer hover:border-f5-red/50 transform transition-all duration-300 hover:scale-[1.03] shadow-2xl">
                    <div class="aspect-[3/4] relative w-full bg-f5-blue-900">
                        <?php if ($cover): ?>
                            <img src="<?php echo esc_url($cover); ?>" alt="<?php echo esc_attr(get_the_title($item)); ?>" class="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-300">
                        <?php endif; ?>
                        <div class="absolute top-2.5 right-2.5 bg-f5-blue/90 text-[10px] font-mono font-bold text-f5-red px-2 py-0.5 rounded border border-white/5">
                            <?php echo esc_html($age_rating); ?>
                        </div>
                        <?php if ($is_exclusive): ?>
                            <div class="absolute bottom-2.5 left-2.5 bg-f5-red text-[10px] font-bold text-black px-2 py-0.5 rounded uppercase font-sans tracking-tight">
                                Exclusivo
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="p-4 bg-f5-blue-950 flex flex-col gap-1.5">
                        <span class="text-[9px] font-mono tracking-wider font-semibold uppercase text-white/40">
                            <?php echo esc_html($genre); ?>
                        </span>
                        <h3 class="font-bold text-sm text-white/90 line-clamp-1 group-hover:text-white transition-colors duration-250">
                            <?php echo esc_html(get_the_title($item)); ?>
                        </h3>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php
// Benefits section
$benefits = [
    ['icon' => 'Smartphone', 'title' => 'Assista onde quiser', 'desc' => 'Disponível em Celulares, Tablets, Smart TVs, Computadores e consoles de videogame sem custo extra.'],
    ['icon' => 'Sparkles', 'title' => 'Conteúdos Exclusivos F5', 'desc' => 'Séries investigativas brutas, bastidores das grandes cidades do Brasil e jornalismo ao vivo 24h.'],
    ['icon' => 'Database', 'title' => 'Downloads sob demanda', 'desc' => 'Baixe episódios inteiros em segundos e assista no avião, metrô ou estrada mesmo sem internet.'],
    ['icon' => 'Tv', 'title' => 'Alta Fidelidade 4K / HDR', 'desc' => 'Assista seus documentários favoritos com cores calibradas de cinema e som Dolby Atmos imersivo.'],
    ['icon' => 'Users', 'title' => 'Multi-perfil Familiar', 'desc' => 'Crie perfis independentes para cada membro da família, incluindo um perfil Kids totalmente vigiado.'],
    ['icon' => 'ShieldCheck', 'title' => 'Sem taxas de cancelamento', 'desc' => 'Assine mensalmente, sem carência ou multas rescisórias. Cancele online em dois cliques a qualquer segundo.'],
];
?>

<section id="beneficios" class="py-24 px-4 sm:px-8 bg-f5-blue border-b border-white/5">
    <div class="max-w-7xl mx-auto">
        <div class="text-left max-w-2xl mb-20 flex flex-col gap-3">
            <span class="text-[10px] font-mono font-bold tracking-[0.2em] text-f5-red uppercase">BENEFÍCIOS EXCLUSIVOS</span>
            <h2 class="text-4xl sm:text-6xl font-black tracking-tighter text-white leading-none">Por que assinar a F5 TV?</h2>
            <p class="text-white/60 text-base font-normal mt-2 leading-relaxed">Elevamos o padrão de streaming nacional com jornalismo tático, documentários premium e tecnologia de ponta.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php foreach ($benefits as $b): ?>
                <div class="p-8 bg-f5-blue-950 border border-white/5 hover:border-white/10 rounded-xl transition-all duration-300 flex flex-col gap-4 group">
                    <div class="p-3 bg-f5-blue w-fit rounded-lg border border-white/5 group-hover:bg-f5-red/10 group-hover:border-f5-red/30 transition duration-350">
                        <span class="text-f5-red text-lg"><?php echo esc_html($b['icon']); ?></span>
                    </div>
                    <h3 class="text-xl font-bold text-white group-hover:text-f5-red transition duration-200"><?php echo esc_html($b['title']); ?></h3>
                    <p class="text-sm text-white/60 leading-relaxed font-normal"><?php echo esc_html($b['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php
// Plans section
$plans = get_posts([
    'post_type' => 'f5tv_plano',
    'posts_per_page' => 3,
    'post_status' => 'publish',
]);
?>

<section id="planos" class="py-24 px-4 sm:px-8 bg-f5-blue border-b border-white/5">
    <div class="max-w-7xl mx-auto">
        <div class="text-left max-w-2xl mb-18 flex flex-col gap-3">
            <span class="text-[10px] font-mono font-bold tracking-[0.2em] text-f5-red uppercase">PREÇOS TRANSPARENTES</span>
            <h2 class="text-4xl sm:text-6xl font-black tracking-tighter text-white leading-none">Escolha o seu plano ideal</h2>
            <p class="text-white/60 text-base font-normal mt-2">Valores simples, táticos e sem fidelidade. Cancele digitalmente na simulação de conta em 2 cliques.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl">
            <?php foreach ($plans as $plan): ?>
                <?php
                $price = get_field('price', $plan->ID) ?: 0;
                $features = get_field('features', $plan->ID) ?: [];
                $is_premium = get_field('is_premium', $plan->ID);
                $plan_id = get_post_field('post_name', $plan->ID);
                ?>
                <div class="flex flex-col rounded-xl relative border overflow-hidden <?php echo $is_premium ? 'bg-gradient-to-b from-[#100c0c] to-[#050505] border-f5-red shadow-2xl' : 'bg-f5-blue-950 border-white/5'; ?>">
                    <?php if ($is_premium): ?>
                        <div class="absolute top-0 right-0 left-0 bg-f5-red text-white text-[9px] font-bold text-center py-1.5 uppercase tracking-widest font-mono">
                            RECOMENDADO / MAIOR QUALIDADE
                        </div>
                    <?php endif; ?>

                    <div class="<?php echo $is_premium ? 'pt-10' : ''; ?> p-8 flex flex-col gap-5 border-b border-white/5">
                        <span class="text-xs font-mono tracking-widest font-bold uppercase text-white/40"><?php echo esc_html(get_the_title($plan)); ?></span>
                        <div class="flex items-baseline gap-1">
                            <span class="text-white/40 font-bold text-sm">R$</span>
                            <span class="text-4xl font-black text-white">
                                <?php echo number_format($price, 2, ',', '.'); ?>
                            </span>
                            <span class="text-white/45 text-xs">/mês</span>
                        </div>
                        <a href="<?php echo esc_url(home_url('/cadastro/?plan=' . $plan_id)); ?>" class="w-full font-bold px-4 py-3.5 rounded text-xs text-center transition tracking-wider uppercase font-mono flex items-center justify-center gap-2 <?php echo $is_premium ? 'bg-f5-red hover:bg-f5-red-700 text-white shadow-lg shadow-f5-red-700/10' : 'bg-white/10 hover:bg-white/20 text-white border border-white/10'; ?>">
                            Definir Plano & Seguir
                        </a>
                    </div>

                    <div class="flex-1 p-8 flex flex-col gap-4 bg-black/20">
                        <?php foreach ($features as $feat): ?>
                            <div class="flex gap-3 items-start text-xs text-white/80">
                                <span class="text-emerald-500 shrink-0 mt-0.5">&#10003;</span>
                                <span class="leading-relaxed font-normal"><?php echo esc_html($feat); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php
// FAQ section
$faq_items = [
    ['q' => 'O que é a F5 TV?', 'a' => 'A F5 TV é uma plataforma de streaming premium nacional controlada pela rede F5 de emissoras. Ela combina transmissões de jornalismo investigativo ao vivo com um catálogo rico sob demanda.'],
    ['q' => 'Como funciona o período de cancelamento?', 'a' => 'Nossa política de assinatura é 100% transparente. Não há contratos de fidelidade. Você pode cancelar a sua assinatura de forma instantânea diretamente na seção "Minha Conta".'],
    ['q' => 'Quais aparelhos são compatíveis?', 'a' => 'Você pode sintonizar a F5 TV em computadores via navegador web, smart TVs modernas, dispositivos de streaming como Chromecast e Apple TV, além de smartphones e tablets.'],
    ['q' => 'O Plano Família suporta visualização em telas simultâneas?', 'a' => 'Sim! Com o Plano Família você pode assistir em até 3 telas simultaneamente em altíssima qualidade Full HD.'],
];
?>

<section id="faq" class="py-24 px-4 sm:px-8 bg-f5-blue border-b border-white/5">
    <div class="max-w-3xl mx-auto">
        <span class="text-[10px] font-mono font-bold tracking-[0.2em] text-f5-red uppercase">PERGUNTAS FREQUENTES</span>
        <h2 class="text-3xl md:text-5xl font-black tracking-tighter text-white mt-2 mb-12">Dúvidas?</h2>

        <div class="flex flex-col gap-4">
            <?php foreach ($faq_items as $faq): ?>
                <div class="bg-f5-blue-950 border border-white/5 rounded-xl p-6">
                    <h3 class="font-bold text-white mb-2"><?php echo esc_html($faq['q']); ?></h3>
                    <p class="text-sm text-white/60 leading-relaxed"><?php echo esc_html($faq['a']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>
